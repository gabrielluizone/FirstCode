users = [["Glever","Gle20"], ["Pedro","Ped12"], ["Admin","1234"]]
newuser = []
todalista = [ [["Gabriel", 18, 14500.0], ["Pedro", 15, 80000.0]], [["Joao", 20, 20.0], ["Neymar", 33, 20000.0], ["Messi", 35, 10000.0]], [["beta1", 10, 120.0], ["beta2", 20, 240.0], ["beta3", 40, 560.0]] ]
lista = []
backmenu = True
while backmenu == True:
	print("\n==========[ HomeData ]==========\n")
	home = int(input("[ 0 ] Acessar Conta\n[ 1 ] Esqueci Minha Senha\n[ 2 ] Cadastrar Usuário\n\n>> "))
	stop = 3
	i = 0
	while stop > 0:
		if home == 0:
			user = str(input("\nUsuário: "))
			pasw = str(input("Senha: "))
			backmenu = False
			posicao = 0
			for iten in users:
				if user == iten[0] and pasw == iten[1]:
					liberado = True
					posicao = posicao + 1 
					print("posição:",posicao)
					break
				elif user != iten[0] and pasw != iten[1]:
					posicao = posicao + 1
					liberado = False
				else:
					print("Erro")
		elif home == 1:
			print("aa")
			backmenu = True
		
		elif home == 2:
			newuser_name = input("\nNome: ")
			newuser_pass = input("Senha: ")
			newuser.append(newuser_name)
			newuser.append(newuser_pass)
			users.append(newuser)
			newuser = []
			todalista.append(lista)
			lista = []
			liberado = False
			backmenu = True
			stop =+0

		#Acesso ao Sistema de Dados
		if liberado == True:
			backstart = True
			while backstart == True:
				print("\n=======[ Bem Vindo ao EverData ]=======\n")
				print("Gostaria de Visualizar os Dados, ou Inserir os Dado?")
				resp = int(input("[ 0 ] Visualizar Dados\n[ 1 ] Inserir Dados\n[ 2 ] Escolher a Quantidade\n[ 3 ] Voltar ao Menu\n\n>> "))
				stop = 0
			#resposta numero 0, visualizar os dados
				if resp == 0:
					todalista.append(lista)
					lista = []
					sublista = todalista[posicao - 1]
					i = 0
					if len(sublista) == 0:
						print("\n=======[ Você não possue Dados ]=======")
					
					while i < len(sublista):
						listaview = sublista[i]
						print("\n=======[ Dados Pessoais {} ]=======".format(i+1))
						print("Nome:", listaview[0])
						print("Idade:", listaview[1])
						print("Saldo:", listaview[2])
						i += 1
					backmenu_resp = int(input("\nDeseja proceguir??\n[ 0 ] Sair\n[ 1 ] Login\n[ 2 ] Inicio\n\n>> "))
					if backmenu_resp == 0:
						backmenu = False
						backstart = False
					elif backmenu_resp == 1:
						backmenu = True
						backstart = False
					elif backmenu_resp == 2:
						backmenu = False
						backstart = True
			#resposta numero 1, inserir dados		
				elif resp == 1:
					i = 0
					ii = 0
					j = 1
					while i < 1:
						ii = ii - ii
						print("\n>>> Cadastro Numero {} <<<".format(j))
						nome = input("Qual o Nome?\n>> ")
						idade = int(input("Qual a Idade?\n>> "))
						saldo = float(input("Qual o Saldo?\n>> "))
						lista.append(nome)
						lista.append(idade)
						lista.append(saldo)
						todalista[posicao - 1].append(lista)
						lista = []
						j = j + 1
						while ii < 1:
							cont = int(input("\n=======[ Deseja acresentar mais dados? ]=======\n[ 0 ] Não\n[ 1 ] Sim\n\n>> "))

							if cont == 1:
								i =+ 0
								ii =+ 1
							
							elif cont == 0:
								i =+ 1
								ii =+ 1
								backmenu = False
								backstart = True
							else:
								print("\n=======[ Digite Corretamente Tente novamente ]=======\n")
								i = 1
								ii =+ 0
				#resposta numero 2, escolher a quantidade inserida
				elif resp == 2:
					i = 0
					j = 1
					quant = int(input("\nQuantos Dados serão inseridos?\n>> "))
					while i < quant:
						print("\n=======[ Cadastro Numero {} ]=======".format(j))
						nome = input("Qual o Nome?\n>> ")
						idade = int(input("Qual a Idade?\n>> "))
						saldo = float(input("Qual o Saldo?\n>> "))
						lista.append(nome)
						lista.append(idade)
						lista.append(saldo)
						todalista[posicao - 1].append(lista)
						lista = []
						j = j + 1
						i = i + 1
					backmenu_resp = int(input("\nDeseja proceguir??\n[ 0 ] Sair\n[ 1 ] Login\n[ 2 ] Inicio\n>> "))
					if backmenu_resp == 0:
						backmenu = False
						backstart = False
					elif backmenu_resp == 1:
						backmenu = True
						backstart = False
					elif backmenu_resp == 2:
						backmenu = False
						backstart = True
					elif resp == 3:
						backmenu = True
						backstart = False
				elif resp == 3:
					backmenu = True
					backstart = False
							
		elif liberado == False:
			if stop > -1 and stop > 0:
				print("Senha Incorreta, você tem {} tentativas".format(stop-1))
				stop = stop - 1
				if stop == 0:
					print("\n===[ Você excedeu o número máximo de tentativas ]===")
			elif stop == -1:
				print("")