# -*- coding: utf-8 -*-
"""
Created on Fri Mar 18 10:24:24 2022

@author: gabri
"""
fim_contagem = int(input("Digite um Valor do Contador\n>> "))
x = 1
while x <= fim_contagem:
    print(x, "\n")
    x = x + 1