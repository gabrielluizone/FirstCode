
# >> Fatec Baixada Santista - Rubens Lara
# Ciências de Dados (Manhã)
# Algoritmos e Introdução a Computação
# Gabriel Luiz / Gabriel Andrade

#Recebimento de Dados das Idades dos Alunos
print("\n======= >> Digite a Idade de Cada Aluno << =======")
idade_jul = int(input("Digite a Idade de Juliana: "))
idade_dav = int(input("Digite a Idade de David: "))
idade_mir = int(input("Digite a Idade de Mirna: "))
idade_joa = int(input("Digite a Idade de João: "))
idade_mon = int(input("Digite a Idade de Mônica: "))

#Recebimento de Dados das Notas
print("\n\n======= >> Digite a Nota de Cada ALNO DO 1º Bimestre << =======")
nota_jul = float(input("Digite a nota do 1º Bimestre de Juliana: "))
nota_dav = float(input("Digite a nota do 1º Bimestre de David: "))
nota_mir = float(input("Digite a nota do 1º Bimestre de Mirna: "))
nota_joa = float(input("Digite a nota do 1º Bimestre de João: "))
nota_mon = float(input("Digite a nota do 1º Bimestre de Mônica: "))

#Lista de Alunos da Turma de Algoritmos e Introdução a Computação
alunos = ["JULIANA CAMARA MONTEIRO", "DAVID HENRIQUE MUNIZ MAIA SANTOS", "MIRNA SILVA DA MATA", "JOAO PEDRO PAIVA CARDOSO", "MONICA ATSUKO ICHIKAWA"]

#Listas com bases nas Notas e Idades
idade = [idade_jul, idade_dav, idade_mir, idade_joa, idade_mon]
nota = [nota_jul, nota_dav, nota_mir, nota_joa, nota_mon]

#Impressão dos Dados das Listas em Ordem a seus Respectivos Alunos
print("\n\n======= >> Dados Referente a os Alunos << =======\n")
print("Aluno:", alunos[0], "|","Idade:",idade[0], "|", "Nota do 1º Bi:",nota[0],"\n")
print("Aluno:", alunos[1], "|","Idade:",idade[1], "|", "Nota do 1º Bi:",nota[1],"\n")
print("Aluno:", alunos[2], "|","Idade:",idade[2], "|", "Nota do 1º Bi:",nota[2],"\n")
print("Aluno:", alunos[3], "|","Idade:",idade[3], "|", "Nota do 1º Bi:",nota[3],"\n")
print("Aluno:", alunos[4], "|","Idade:",idade[4], "|", "Nota do 1º Bi:",nota[4],"\n")