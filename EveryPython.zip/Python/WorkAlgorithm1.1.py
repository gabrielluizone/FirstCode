
# >> Fatec Baixada Santista - Rubens Lara
# Ciências de Dados (Manhã)
# Algoritmos e Introdução a Computação
# Gabriel Luiz / Gabriel Andrade

print("\n=== >> Digite os Nomes em Maiusculo sem Acento << ===")
aluno = input("Qual aluno deseja saber se foi Aprovado?\n>> ")

if aluno == "MARIA":
    his = 5.6
    geo = 6.7
    por = 7.0
    mat = 10.0
    cie = 4.0
    lit = 8.0
    media = (his + geo + por + mat + cie + lit)/6
    
elif aluno == "TANIA":
    his = 2.3
    geo = 6.6
    por = 8.0
    mat = 5.5
    cie = 10.0
    lit = 5.0
    media = (his + geo + por + mat + cie + lit)/6

elif aluno == "JOSE":
    his = 7.7
    geo = 4.0
    por = 7.0
    mat = 7.9
    cie = 2.2
    lit = 6.5
    media = (his + geo + por + mat + cie + lit)/6

elif aluno == "DANIEL":
    his = 9.0
    geo = 10.0
    por = 3.3
    mat = 8.0
    cie = 6.0
    lit = 4.6
    media = (his + geo + por + mat + cie + lit)/6
    
else:
    print("\n>> O Nome não consta na Lista de Alunos <<")
    media = -1

if media >= 5:
    print("\n============================================")
    print("\nPelo resultado artimética da média,\n>>",aluno,"foi APROVADO(A)")
    print(">> Parabéns pelos seu Esforço")
    print("\n======= >> Suas notas <<=======")
    print("\nMatemática: ",mat)
    print("Português: ",por)
    print("Ciências: ",cie)
    print("Literátura: ",lit)
    print("Geografia: ",geo)
    print("História: ",his)
    print("Média: ",media)

elif media < 5 and media >= 0:
    print("\n============================================")
    print("\nPelo resultado artimética da média,\n>>",aluno,"foi REPROVADO(A)")
    print(">> Não desanime, estude Mais")
    print("\n======= >> Suas notas <<=======")
    print("\nMatemática: ",mat)
    print("Português: ",por)
    print("Ciências: ",cie)
    print("Literátura: ",lit)
    print("Geografia: ",geo)
    print("História: ",his)
    print("Média: ",media)

elif media == -1:
    print("Digite novamente")