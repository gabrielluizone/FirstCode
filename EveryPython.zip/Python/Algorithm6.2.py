# -*- coding: utf-8 -*-
"""
Created on Fri Apr  1 10:11:05 2022

@author: gabri
"""

frase = ["o que aptam", 'na estrada', 'por viver', 'filme', 'NomadLand', 'que conta', 'de pessoas', 'a historis', 'é um']
print('\n\n A frase ordenada é:\n>> ', frase[4:5], frase[8:9], frase[3:4], frase[5:6], frase[7:8], frase[6:7], frase[0:1], frase[2:3], frase[1:2] )