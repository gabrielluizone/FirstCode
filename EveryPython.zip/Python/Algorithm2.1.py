#Nome do Aluno
nome = "Gabriel"
sobnome = "Luiz"
vazio = " "
#Valores das Matérias
media = 0.0
portugues = 9.4
matematica = 7.6
historia = 8.0
geografia = 6.4
edfisica = 10.0

#aluno
print("\nNome:",nome + vazio + sobnome)

#suas notas
print("\nNota de Portugues:", portugues)
print("Nota de Matemática:", matematica)
print("Nota de História:", historia)
print("Nota de Geografia", geografia)
print("Nota de Ed. Física", edfisica)

print("\nCalculos das Médias")

#Calculo das Médias
print("\nValor da Média:", media)
media = (portugues + matematica + historia) / 3
print("Média de Port, Mat, e Hist:", media)
media = (portugues + matematica) / 2
print("Média de Port e Mat:", media)
media = (portugues + matematica + historia + geografia + edfisica) / 5
print("Média de Todas as Matérias:", media)

nome2 = input("DIGITE O NOME")