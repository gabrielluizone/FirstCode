
"""
Created on Fri Mar 11 10:43:13 2022

@author: GabrielLuiz
"""

quant = int(input("• Qual Quantidade de peças?\n>> "))
if quant < 20:
    preço_unidade = 35.00
else:
    if quant <= 30:
        preço_unidade = 28.00
    else:
        preço_unidade = 20.00
print("\n• Quantidade de peças:\n>> ",quant)
print("\n• Preço por Unidade:\n>> ",preço_unidade)
print("\n\n===== >> Total a Pagar << =====")
print(f"\nTotal a pagar: R$ {preço_unidade*quant:8.2f}")
