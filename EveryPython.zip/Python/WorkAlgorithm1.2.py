"""

Exercício 2

Ciências de Dados - 1 Ciclo
Algoritmos e Introdução a Computação
Grupo: Gabriel Andrade & Gabriel Luiz

"""
("---------------------------------------------------------------------------")

funcionário = input("Nome do funcionário: ") 
idade = int(input("Idade do funcionario: ")) 
endereço = input("Endereço do funcionario: ")
função = input("Cargo do funcionario: ")
salário = float(input("salário: $"))

("---------------------------------------------------------------------------")

reajuste = 0.20 * salário + salário

("---------------------------------------------------------------------------")

print("\n===== >> Dados do Funcionário << =====\n")
print("Nome:", funcionário)
print("Idade:", idade)
print("Endereço:", endereço)
print("Função:", função)
print("Reajuste Salarial em 20%:", reajuste)

("---------------------------------------------------------------------------")
