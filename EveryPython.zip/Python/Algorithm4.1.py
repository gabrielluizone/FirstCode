# -*- coding: utf-8 -*-
"""
Created on Fri Mar 18 10:43:47 2022

@author: gabri
"""

limite = int(input("Digite um Valor Limite da contagem de numeros pares\n>> "))
contador = 0
while contador <= limite:
    if contador % 2 == 0:
        print(contador, "\n")
    contador = contador + 1
    
limite = int(input("Digite um Valor Limite da contagem de numeros impar\n>> "))
contador = 0
while contador <= limite:
    if contador % 2 == 1:
        print(contador, "\n")
    contador = contador + 1