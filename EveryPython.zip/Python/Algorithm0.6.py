"""
Exercício 1

"""

#dados do funcionario
funcionario = "Gabriel Luiz"
idade = 19
endereço = "Araçatuba, 42"
função = "Data Scientist"
salario = 12000

#título
print("\n\n=========== >> Dados do Funcionário << ===========")

#imprimir no console
print("\nFuncionário >>>",funcionario,"<<<",)
print("Idade do Funcionario >>>",idade,"<<<")
print("Endereço de Residencia >>>",endereço,"<<<")
print("Cargo >>>",função,"<<<")
print("Salário Mensal >>>",salario,"<<<")

#título
print("\n\n=========== >> Tipo de Dados << ===========")

#identificar os tipos de dados
print("\nFuncionário >>>",type(funcionario),"<<<")
print("Idade do Funcionario >>>",type(idade),"<<<")
print("Endereço de Residencia >>>",type(endereço),"<<<")
print("Cargo >>>",type(função),"<<<")
print("Salário Mensal >>>",type(salario),"<<<")

#título
print("\n\n=========== >> False e True << ===========")

#Verificar Not e True
print("\nResuldado de Not True >>", not True)
print ("Resultado de False and Not True >>", False and not True)
print("Resultado Final de True or False and not True >>", True or False and not True)

#título
print("\n\n=========== >> Not e False nos Dados << ===========")

print("\nSalário maior de R$ 1000 e Idade maior de 18 =", salario > 1000 and idade > 18)





