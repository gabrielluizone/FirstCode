# -*- coding: utf-8 -*-
"""
Created on Fri Mar 18 11:50:34 2022

@author: gabri
"""
senha = "Python1803"
s = 1
while s <= 3:
    dig_senha = input("Digite sua Senha\n>> ")
    if dig_senha == senha:
        print("\nBom vindo de Volta")
        break
    else:
        s = s + 1
    print("\nSenha Incorreta, Digite Novamente")