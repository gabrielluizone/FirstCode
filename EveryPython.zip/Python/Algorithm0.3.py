# -*- coding: utf-8 -*-
"""
Created on Fri Feb 18 11:40:51 2022

@author: gabri
"""
Batata = 21
One = "Universe"

#Dados de Funcionarios
a = "João"
b = 35
c = "Av. Senador Feijó"
d = "Administrativo"
e = 3500

#comando de impressão console
print ("O nome do Funcionário é",a)
print ("Ele tem a Idade de",b)
print ("E mora no Endereço",c)
print ("Sua Função é",d)
print ("E seu Salário mensal é de= ",e)


print ("Blablabla tete",Batata)

print ("Hello,",One)