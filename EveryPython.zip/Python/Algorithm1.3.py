# -*- coding: utf-8 -*-
"""
Created on Fri Mar 11 12:07:32 2022

@author: planc
"""
("---------------------------------------------------------------------------")

temperatura = float(input("Insira o valor da temperatura ambiente em graus celsius: "))
print("\n----------Temperatura inserida----------\n")


("---------------------------------------------------------------------------")

def avaliação_de_tempo(temperatura):
    
    if temperatura <= 16:
        print("A temperatura é de",temperatura,"graus celsius, portanto o tempo está frio")
        print("\n----------Tempo avaliado----------\n")
    else: 
        if temperatura > 16 and temperatura <= 30 :
            print("A temperatura é de",temperatura,"graus celsius, portanto o tempo está agradável")
            print("\n----------Tempo avaliado----------\n")
        else:
            if temperatura > 30 :
                print("A temperatura é de",temperatura,"graus celsius, portanto o tempo está agradável")
                print("\n----------Tempo avaliado----------\n")

("---------------------------------------------------------------------------")

avaliação_de_tempo(temperatura)

("---------------------------------------------------------------------------")
