lista = [8, 16, 20, -3]
num_lista = int(input("Digite o numero que deseja pesquisar\n>> "))
for i in lista:
    if i == num_lista:
        print("Elemento pesquisado = ", i)
        break
else:
    print("Elemento não encontrado")