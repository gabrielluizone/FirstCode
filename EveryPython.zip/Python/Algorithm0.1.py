# -*- coding: utf-8 -*-
"""
Spyder Editor

This is a temporary script file.
"""
#atribuição de valores as variaveis de tipo int
a = 45
b = -13
#atribuições de valores a variaveis de tip string
c = "Ciências de Dados"
d = '@*&&&$'
e = ''
f = "20"

#comando de impressão console
print ("a = ",a)
print ("d = ",b)
print ("c = ",c)
print ("d = ",d)
print ("e = ",e)
print ("f = ",f)