Lista = [8, 16, 20, -3]
numero_lista = int(input("\nDigitar numero da lista que deseja pesquisar\n>> "))
numero_encontrado = False
k = 0
while k < len(Lista):
    if Lista[k] == numero_lista:
        numero_encontrado = True
        break
    k += 1
if numero_encontrado:
    print("{} achado na posiçãao {}".format(numero_lista, k))
else:
    print("Número não encontrado")