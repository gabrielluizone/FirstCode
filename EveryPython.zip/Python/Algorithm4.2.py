# -*- coding: utf-8 -*-
"""
Created on Fri Mar 18 11:09:33 2022

@author: gabri
"""

valor = int(input("Digite um Numero para a Tabuada\n>> "))
n = 1
while n <= 10:
    print(valor, "\tx", n, "\t=", valor * n,"\n")
    n = n + 1
