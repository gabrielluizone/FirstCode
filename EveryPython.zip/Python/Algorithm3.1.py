# -*- coding: utf-8 -*-
"""
Created on Fri Mar 11 09:48:10 2022

@author: ga
"""

quant = int(input("• Qual Quantidade de peças?\n>> "))
if quant <= 30 and quant >= 20:
    preçouni = 28.00
if quant < 20:
    preçouni = 35.00
if quant > 30:
    preçouni = 20.0
print("\n\n===== >> Dados da Compra << =====")
print("\nQuantidade de Peças de Roupa:\n>> ",quant)
print("\nPreço por Unidade de acordo com a Quantidade:\n>> ",preçouni)
print(f"\nPreço da compra:\n>> R$ {preçouni*quant:8.2f}")
print("\n\nQuant. menor/igual a 30, e maior/igual a 20:\n>> ", quant <= 30 and quant >= 20)
print("Quantidade menor que 20:\n>> ", quant < 20) 
print("Quantidade maior que 30:\n>> ", quant > 30)
   
