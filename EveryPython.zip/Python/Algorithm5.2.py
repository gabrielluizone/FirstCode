# -*- coding: utf-8 -*-
"""
Created on Fri Mar 25 11:03:37 2022

@author: gabri
"""

notas = [4.7, 5.6, 8.9, 3.5, 6.6, 7.4, 8.0, 9.5]
soma = 0.0
i = 0
while i < 8:
    soma += notas[1]
    i + 1
print(f"Média: {soma/i:5.2f}")