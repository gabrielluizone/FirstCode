# -*- coding: utf-8 -*-
"""
Created on Fri Mar  4 12:32:47 2022

@author: planc
"""
("---------------------------------------------------------------------------")

#quantidade de itens da compra
arroz_kg = 5.00
feijão_kg = 3.00
açúcar_kg = 2.00
batata_kg = 3.50
óleo_L = 5.00
bolacha_de_água_e_sal_pac = 1
bolacha_de_maizena_pac = 1
banana_dúzia = 1.5 
couve_em_flor_mc = 2
leite_em_pó_lt = 2

("---------------------------------------------------------------------------")
#solicitando que o usuário insira o valor individual de produtos requisitados
print("\n\n----------Insira o Preço dos Produtos----------\n\n")
preço_de_arroz = float(input("preço por quilo de arroz: "))
preço_de_feijão = float(input("preço por quilo de feijão: "))
preço_de_açúcar = float(input("preço por quilo de açúcar: "))
preço_de_batata = float(input("preço por quilo de batata: "))
preço_de_óleo = float(input("preço por litro de óleo: "))
preço_de_bolacha_água = float(input("preço por pactore de bolacha de água e sal: "))
preço_de_bolacha_maizena = float(input("preço por pacote de bolacha de maizena: "))
preço_de_banana = float(input("preço por dúzia de bananas: "))
preço_de_couve = float(input("preço por maço de couve-flor: "))
preço_de_leite_pó = float(input("preço por lata de leite em pó: "))

("---------------------------------------------------------------------------")

#Multiplicando o número de produtos desejados pelos preços indiviuais, resultando no custo individual
print("\n\n----------Preços individuais computados----------\n\n")
preço_final_arroz = arroz_kg * preço_de_arroz
print("preço final (arroz |",arroz_kg,"Kg |",preço_de_arroz,"R$/Kg): R$",preço_final_arroz)
preço_final_feijão = feijão_kg * preço_de_feijão
print("preço final (feijão |",feijão_kg,"Kg |",preço_de_feijão,"R$/Kg): R$",preço_final_feijão)
preço_final_açúcar = açúcar_kg * preço_de_açúcar
print("preço final (açúcar |",açúcar_kg,"Kg |",preço_de_açúcar,"R$/Kg): R$",preço_final_açúcar)
preço_final_batata = batata_kg * preço_de_batata
print("preço final (batata |",batata_kg,"Kg |",preço_de_batata,"R$/Kg): R$",preço_final_batata)
preço_final_óleo = óleo_L * preço_de_óleo
print("preço final (óleo |",óleo_L,"L |",preço_de_óleo,"R$/L): R$",preço_final_óleo)
preço_final_bolacha_água = bolacha_de_água_e_sal_pac * preço_de_bolacha_água
print("preço final (bolacha de água e sal |",bolacha_de_água_e_sal_pac,"Pacote |",preço_de_bolacha_água,"R$/Pac): R$",preço_final_bolacha_água)
preço_final_bolacha_maizena = bolacha_de_maizena_pac * preço_de_bolacha_maizena
print("preço final (bolacha de maizena |",bolacha_de_maizena_pac,"Pacote |",preço_de_bolacha_maizena,"R$/Pac): R$",preço_final_bolacha_maizena) 
preço_final_banana = banana_dúzia * preço_de_banana
print("preço final (banana |",banana_dúzia,"duzia |",preço_de_banana,"R$/Duzia): R$",preço_final_banana)
preço_final_couve = couve_em_flor_mc * preço_de_couve
print("preço final (couve em flor |",couve_em_flor_mc,"Maço |",preço_de_couve,"R$/Maço): R$",preço_final_couve) 
preço_final_leite_pó = leite_em_pó_lt * preço_de_leite_pó
print("preço final (leite em pó |",leite_em_pó_lt,"Lata de 1Kg |",preço_de_leite_pó,"R$/Kg): R$",preço_final_leite_pó)

print("\n\n----------Custo total computado----------\n\n")
#calculo e impressão da soma de todos os valores
custo_total = (preço_final_arroz + preço_final_feijão + preço_final_açúcar + preço_final_batata + preço_final_óleo +
preço_final_bolacha_água + preço_final_bolacha_maizena + preço_final_banana + preço_final_couve + preço_final_leite_pó)
    
print("Total a pagar: R$ ", custo_total)
limite = float(input("Qual seu limite de compra em Dinheiro ou Crédito?: "))

print("\n\n----------Forma de pagamento identificada----------\n\n")
#determinando de qual forma o valor deve ser pago
if custo_total<=limite:
    print("O valor de",custo_total,"reais deverá ser pago em dinheiro 💸")
if custo_total>limite:
    print("O valor de",custo_total,"reais deverá ser pago de forma parcelada via cartão de crédito 💳")


