# -*- coding: utf-8 -*-
"""
Created on Fri Mar 11 12:01:59 2022

@author: GabriEver
"""

temp = float(input("Temperatura Ambiente\n>> "))
if temp > 16 and temp <= 30:
    clima = "Agradavel"
else:
   if temp > 30:
        clima = "Quente"
   else:
       if temp <= 16:
           clima = "Frio"
print("O Clíma está",clima,"com temperatura atual de ",temp,"°C")
