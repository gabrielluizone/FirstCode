#Gabriel Luiz
"""
Codigo -- Preço
1 -- 13.30
2 -- 1.40
3 -- 19.00
4 -- 123.79
5 -- 44.33
"""
cod = int(input("Digite o código do produto\n>> "))
if cod == 1:
    preco_produto = 13.30
elif cod == 2:
    preco_produto = 1.40
elif cod == 3:
    preco_produto = 19.00
elif cod == 4:
    preco_produto = 123.79
elif cod == 5:
    preco_produto = 44.33
else:
    print("Somente códigos de 1 a 5:\n>> O código ", cod,"inserido, não é válido")
    preco_produto = 0.00
    
print("\nCódigo do Produto:\n>> ",cod)
print(f"\nPreço do Produto pelo Código:\n>> R$ {preco_produto:4.2f}")