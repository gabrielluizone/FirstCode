pesquisa = int(input('Qual Numero?\n>> '))
lista = [8, 16, 20, -3]
a = len(lista)
i = 0
while i < a:
    if lista[i] == pesquisa:
        print('Número esta presente')
        break
    elif lista[i] != pesquisa:
        print('O Número não foi encontrado')
        break
    i += 1