nome = input("Digite seu Nome:\t")
ende = input("Digite deu Endereço:\t")
cpf = input("Digite seu CPF:\t")
renda = float(input("Digite sua Renda Anual: R$ "))
imppago = float(input("Digite o Valor do Imposto Pago: R$ "))
imposto = renda * 0.15 - imppago

if renda <= 44.000:
    imposto = 0.0
    print("========== > Resultado < ==========")
    print("\n\n Voc� est� livre de pagar Imposto: ")
else:
    print("========== > Resultado < ==========")
    print("\n\nValor a ser pago de Imposto: ", imposto)