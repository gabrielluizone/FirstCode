# -*- coding: utf-8 -*-
"""
Created on Fri Mar 11 12:35:08 2022

@author: gabri
"""

print ("=== >> Duração das Estações do Ano << ===")
estacao = input("Qual estação você queira saber a duração?\n>> ")

if estacao == "primavera" or "Primavera":
    inicio = "20 Setembro"
    fim = "20 de Dezembro"
else:
    if estacao == "verao" or "Verao" or "Verão" or "Verão":
        inicio = "21 Dezembro"
        fim = "19 de Março"
    else:
        if estacao == "outono" or "Outono":
            inicio = "20 Março"
            fim = "19 de Junho"
        else:
            if estacao == "inverso" or "Inverno":
                inicio = "20 de Junho"
                fim = "22 de Dezembro"
            else:
                print("Porfavor digite corretamente")
                
print("\nEstação atual é",estacao,"com inicio de",inicio,"e término em",fim)
print("\nEstação: ",estacao)
print("Inicio: ",inicio)
print("Fim: ",fim)
    