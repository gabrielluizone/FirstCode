Temp = int(input("Verificação da Temperatura: "))
DorCabeça = input("Confirmação para Dor de Cabeça: ").lower()
Coriza = input("Confirmação para Coriza: ").lower()

if Temp > 37 and DorCabeça == "s" or Coriza == "s"
print("O P aciente está com Gripe")

else:
    print("O Paciente não está com Gripe")
    
    situação = Temp > 3 and DorCabeça == "s" or Coriza == "s"
    print(f"Gripe: ")