# -*- coding: utf-8 -*-
"""
Created on Fri Feb 25 12:03:47 2022

@author: planc
"""
("---------------------------------------------------------------------------")

funcionário = input("Nome do funcionário: ") 
idade = int(input("Idade do funcionario: ")) 
endereço = input("Endereço do funcionario: ")
função = input("Cargo do funcionario: ")
salário = float(input("salário: $"))

("---------------------------------------------------------------------------")

reajuste = 0.20 * salário + salário

("---------------------------------------------------------------------------")

print("\n===== >> Dados do Funcionário << =====\n")
print("Nome:", funcionário)
print("Idade:", idade)
print("Endereço:", endereço)
print("Função:", função)
print("Reajuste Salarial em 20%:", reajuste)

("---------------------------------------------------------------------------")
