for i in range(10):
    print(i)
print('\n')
for i in range (3,8):
    print(i)