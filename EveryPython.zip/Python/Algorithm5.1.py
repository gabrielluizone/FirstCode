# -*- coding: utf-8 -*-
"""
Created on Fri Mar 25 10:17:11 2022

@author: gabri
"""

coleção = ["\n\nMaria", 22, "anos e salário de R$", 1287.98]
print(coleção[0])
print(coleção[1])
print(coleção[2])
print(coleção[3])