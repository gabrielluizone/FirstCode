#Criar lista com 10 elementos
i = 0
lista = []
while i < 20:
    i += 1
    lista.append(i)

#listas par e impar vazias
lista_par = []
lista_impar = []
soma = [0 ,0 ,0 ,0 ,0 ,0 ,0 ,0 ,0 ,0]
#completar lista par
lista_par = list(range(0, 20, 2))

#completar lista impar
lista_impar = list(range(1, 20, 2))

#soma
for k in range(10):
    soma[k] = lista_par[k] + lista_impar[k]


print(lista_par)
print(lista_impar)
print("Soma Total", soma)