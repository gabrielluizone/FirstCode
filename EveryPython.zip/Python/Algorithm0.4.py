# -*- coding: utf-8 -*-
"""
Created on Fri Mar  4 20:33:11 2022

@author: gabriever
"""

print("\n\n=======[ Cadastro de Big Dados ]=======")

nome = input("Digite seu Nome:\n>>\t")
sobrenome = input("Digite seu Sobrenome:\n>>\t")
idade = int(input("Digite sua Idade:\n>>\t"))
rua_av = input("Mora em uma Rua ou Avenida?")
rua1 = 
if rua_av = "Rua"
    endereço = input("Qual sua Rua?")
else
    endereço = input("Qual sua Av.?")
endereço = input("Digite seu Endereço:\n>>\t")
bairro = input("Digite seu Bairro:\n>>\t")
numero = int(input("Agora o Numero da Casa:\n>>\t"))
salario = input("Digite seu Salário:\n>>\t")
familia = int(input("Quantos Membros são da sua Familia?\n>>\t"))

print("\n\n=======[ Resultados ]=======\n")
print("Individuo:\t",nome + "\t" + sobrenome,"\t""com""\t"idade"\t""anos")
print("Mora na")



