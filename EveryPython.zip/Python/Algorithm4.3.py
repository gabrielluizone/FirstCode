# -*- coding: utf-8 -*-
"""
Created on Fri Mar 18 11:41:03 2022

@author: gabri
"""
comando = "Continuar"
n = 3
while comando != "Parar":
    comando = input("Deseja Parar ou Continuar?\n>> ")
    n = n - 1
    print(n,"\t", comando)
