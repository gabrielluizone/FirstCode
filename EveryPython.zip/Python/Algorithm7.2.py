lista = [8, 16, 20, -3]
a = len(lista)
i = 0
while i < a:
    print("Numero: ",lista[i])
    i += 1