#Gabriel Luiz

lista2 = [1, 2, 3, 4, 5, 6,]


print("\n\nLista[0:6] = Lista Completa ", lista2[0:6])
print("Lista[:6] = Lista Completa ", lista2[:6])
print("Lista[:-1] = menos um elem. a partir do fim da lista ", lista2[:-1])
print("Lista[:-2] = menos dois elem. a partir do fim da lista ", lista2[:-2])
print("Lista[:-3] = menos três elem. a partir do fim da lista ", lista2[:-3])
print("Lista[:-5] = menos cinco elem. a partir do fim da lista ", lista2[:-5])
print("Lista[0:1] = um elem. a partir do primeiro da lista ", lista2[0:1])
print("Lista[0:2] = dois elem. a partir do primeiro da lista ", lista2[0:2])
print("Lista[0:2] = três elem. a partir do primeiro da lista ", lista2[0:3])
print("Lista[0:5] = cinco primeiros elem. da lista ", lista2[0:5])
print("Lista[0:6] = todos os elem. da lista ", lista2[0:6])
print("Lista[1:3] = entre o 2º e o 4º (não incluido) elem. da lista ", lista2[1:3])
print("Lista[1:4] = entre o 2º e o 5º (não incluido) elem. da lista ", lista2[1:4])
print("Lista[2:5] = entre o 3º e o 6º (não incluido) elem. da lista ", lista2[2:5])
print("Lista[4:5] = 5º elem. da lista ", lista2[4:5])
print("Lista[5:6] = 6º elem. da lista ", lista2[5:6])
print("Lista[5:7] = 6º elem. da lista ", lista2[5:7])