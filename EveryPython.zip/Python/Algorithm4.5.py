# -*- coding: utf-8 -*-
"""
Created on Fri Mar 18 10:11:25 2022

@author: gabri
"""

x = 1
while x <= 5:
    print(x, "\n")
    x = x + 1